# Private modules

Modules here are ignored by git and should contain personal settings you don't
want DOOM updates to interfere with (if that matters to you).

I include mine as a reference. However, a warning to non-evil users: my module
is fiercely evil-mode-oriented.
